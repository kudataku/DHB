#!/bin/sh

clear
while true; do printf %s "$(date): "; python3 hunt.py; done


