#!/bin/sh

python3 hunt.py
