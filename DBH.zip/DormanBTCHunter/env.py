# RENAME THIS FILE TO env.py and edit the variables below


# instances/time info
NUM_INSTANCES=0
MAX_SECONDS=60

# output file
OUT_FILE="./keys-found.txt"

# email info
SEND_EMAILS = True
SEND_TO=["diantaralangit7@gmail.com"]
SEND_FROM="diantaralangit7@gmail.com"
USER='diantaralangit7@gmail.com'
PASS='cxcq cnrx zwqb rjxm'
SMTP_HOST='smtp.gmail.com'
SMTP_PORT=587
subject = 'BitCoin Hunter Found Something !'
email_text = "BitCoin Hunter discovered a matching public and private key for a bitcoin address. Please check your server for the keys-found.txt file to see what you have found"

